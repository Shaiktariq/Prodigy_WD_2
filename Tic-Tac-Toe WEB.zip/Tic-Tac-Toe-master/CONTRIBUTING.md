# Want to Contribute?

Here are some things, which I want to implement in due course of time!

- ~Let user choose option to who wants **X** and who wants **0**.~
- Make it two way-game, **Computer vs Human** and **Human vs Human**.
- ~Maintain a Leader-Board for all players who have played.~
- Add more graphics, to enjoy user-interface.

Any such changes if you can make or have any other ideas, please do contribute!

For any queries you may send me an e-mail on shahmishal1998@gmail.com
